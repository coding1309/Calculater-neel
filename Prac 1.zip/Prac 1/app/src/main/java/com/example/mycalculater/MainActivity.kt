package com.example.mycalculater

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var toastButton: Button
    private lateinit var countButton: Button
    private lateinit var countTextView: TextView
    private var count = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toastButton = findViewById(R.id.toastButton)
        countButton = findViewById(R.id.countButton)
        countTextView = findViewById(R.id.countTextView)
       

        toastButton.setOnClickListener {
            val toast = Toast.makeText(this, "Welcome!", Toast.LENGTH_SHORT)
            toast.show()
        }

        countButton.setOnClickListener {
            count++
            countTextView.text = count.toString()
        }
    }

}